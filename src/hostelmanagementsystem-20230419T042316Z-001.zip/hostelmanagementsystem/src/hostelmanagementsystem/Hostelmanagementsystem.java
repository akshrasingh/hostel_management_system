package hostelmanagementsystem;


public class Hostelmanagementsystem 
{
    public static void main(String[] args)
    {
        
    }
    
}
